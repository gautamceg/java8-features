package com.example.test;

import java.util.ArrayList;
import java.util.List;
/**
 * In Bakery department: From 8 to 10
 *
 *
 *
 * In Checkout department: From 10 to 12
 *
 *
 *
 * In Diary department: From 14 to 19
 */
public class ScheduleDemo {

    private List<Shift> inputShifts ;


    public static void main(String[] args) {
        // Load data
        DataProvider dataProvider = new DataProvider();
        Shift shift1 = new Shift(8, 10);
        dataProvider.loadShiftData(shift1);
    }

    public List<Shift> getContinuousShiftList() {
        inputShifts.stream().map(shift -> combineShifts())

    }


    public void loadShiftData(Shift shift){
        inputShifts.add(shift);
    }

    public List<Shift> getShiftData() {
        return inputShifts;
    }

    public List<Shift> getContinuousShiftList(List<Shift> inputShifts) {
        List<Shift> result = new ArrayList<>;
        for (Shift shift : inputShifts){
            int startTime = shift.getStartTime();
            int endTime = shift.getEndTime();

        }
        List<Shift> tempShift = inputShifts;
        for( int i=0 ; i<inputShifts.size() ; i++){

        }
        /**
         *  * In Bakery department: From 8 to 10
         *  *
         *  * In Checkout department: From 10 to 12
         *  In Checkout department: From 12 to 13
         *  * In Diary department: From 14 to 19
         *  10               == 10
         * shift.getEndTime() == nextShift.getStartTime();
         *
         *  nextShift.getEndTime
         */

    }


}
